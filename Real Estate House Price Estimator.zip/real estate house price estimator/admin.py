from getpass import getpass
from app import app
from models import db, Admin
from werkzeug.security import generate_password_hash


def create_admin():
    with app.app_context():
        existing = Admin.query.first()
        if existing:
            print("An admin account already exists. No new account was created.")
            return

        print("Create your EstatePredict administrator account")
        name = input("Admin name: ").strip()
        email = input("Admin email: ").strip()
        password = getpass("Admin password: ")
        confirm = getpass("Confirm password: ")

        if not name or not email or not password:
            print("Name, email and password are required.")
            return
        if password != confirm:
            print("Passwords do not match.")
            return
        if Admin.query.filter_by(email=email).first():
            print("An admin with that email already exists.")
            return

        db.session.add(Admin(
            name=name,
            email=email,
            password=generate_password_hash(password)
        ))
        db.session.commit()
        print("Admin account created successfully.")
        print("Use the email and password you just entered to sign in.")


if __name__ == "__main__":
    create_admin()

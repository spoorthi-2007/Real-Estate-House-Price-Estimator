from datetime import datetime
from zoneinfo import ZoneInfo
from flask_sqlalchemy import SQLAlchemy

IST = ZoneInfo('Asia/Kolkata')

def get_ist_now():
    return datetime.now(IST).replace(tzinfo=None)

db = SQLAlchemy()


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)

    created_at = db.Column(
        db.DateTime,
        default=get_ist_now
    )

    predictions = db.relationship(
        "Prediction",
        backref="user",
        lazy=True,
        cascade="all, delete-orphan"
    )

    login_history = db.relationship(
        "LoginHistory",
        backref="user",
        lazy=True,
        cascade="all, delete-orphan"
    )


class Admin(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)

    created_at = db.Column(
        db.DateTime,
        default=get_ist_now
    )


class Prediction(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    user_id = db.Column(
        db.Integer,
        db.ForeignKey("user.id"),
        nullable=False
    )

    location = db.Column(db.String(100))
    sub_location = db.Column(db.String(100))
    area = db.Column(db.Float)
    bedrooms = db.Column(db.Integer)
    bathrooms = db.Column(db.Integer)
    parking = db.Column(db.Integer)
    floor = db.Column(db.Integer)

    predicted_price = db.Column(db.Float)

    created_at = db.Column(
        db.DateTime,
        default=get_ist_now
    )


class LoginHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    user_id = db.Column(
        db.Integer,
        db.ForeignKey("user.id"),
        nullable=False
    )

    login_time = db.Column(
        db.DateTime,
        default=get_ist_now
    )

    logout_time = db.Column(db.DateTime)

    ip_address = db.Column(db.String(50))
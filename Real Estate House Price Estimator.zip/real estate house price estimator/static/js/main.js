document.addEventListener("DOMContentLoaded", function () {

    const counters = document.querySelectorAll(".counter");

    const speed = 200;

    const animateCounter = (counter) => {

        const target = Number(counter.getAttribute("data-target"));

        let current = 0;

        const increment = target / speed;

        const updateCounter = () => {

            current += increment;

            if (current < target) {

                counter.textContent = Math.ceil(current);

                requestAnimationFrame(updateCounter);

            } else {

                counter.textContent = target.toLocaleString();

            }
        };

        updateCounter();
    };


    const observer = new IntersectionObserver(
        (entries, observer) => {

            entries.forEach((entry) => {

                if (entry.isIntersecting) {

                    animateCounter(entry.target);

                    observer.unobserve(entry.target);

                }

            });

        },
        {
            threshold: 0.5
        }
    );


    counters.forEach((counter) => {

        observer.observe(counter);

    });

});
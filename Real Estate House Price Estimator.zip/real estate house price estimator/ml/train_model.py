import os
import pandas as pd
import joblib
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestRegressor
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATASET_PATH = os.path.join(BASE_DIR, "dataset", "house_prices.csv")
MODEL_PATH = os.path.join(BASE_DIR, "ml", "house_price_model.pkl")

df = pd.read_csv(DATASET_PATH, sep="\t")

required = ["location", "sub_location", "area", "bedrooms", "bathrooms", "parking", "floor", "price"]
missing = [c for c in required if c not in df.columns]
if missing:
    raise ValueError(f"Missing dataset columns: {missing}")

df = df.dropna(subset=required)

X = df[["location", "sub_location", "area", "bedrooms", "bathrooms", "parking", "floor"]]
y = df["price"]

preprocessor = ColumnTransformer(
    transformers=[
        ("location", OneHotEncoder(handle_unknown="ignore"), ["location", "sub_location"])
    ],
    remainder="passthrough"
)

pipeline = Pipeline([
    ("preprocessor", preprocessor),
    ("model", RandomForestRegressor(
        n_estimators=400,
        random_state=42,
        min_samples_leaf=1
    ))
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42
)

pipeline.fit(X_train, y_train)
pred = pipeline.predict(X_test)

mae = mean_absolute_error(y_test, pred)
rmse = mean_squared_error(y_test, pred) ** 0.5
r2 = r2_score(y_test, pred)

print(f"Dataset rows : {len(df)}")
print(f"Locations    : {df['location'].nunique()}")
print(f"Sub-locations: {df['sub_location'].nunique()}")
print(f"MAE          : {mae:.2f} lakhs")
print(f"RMSE         : {rmse:.2f} lakhs")
print(f"R2           : {r2:.2f}")

joblib.dump(pipeline, MODEL_PATH)
print(f"Model saved to: {MODEL_PATH}")

from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import os
import joblib
import pandas as pd

app = Flask(__name__)
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'real-estate-secret-key-change-me')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(BASE_DIR, 'database', 'realestate.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

from models import db, User, Admin, Prediction, LoginHistory, get_ist_now
db.init_app(app)

from datetime import datetime
from zoneinfo import ZoneInfo

@app.context_processor
def inject_now():
    return {'now': datetime.now()}

MODEL_PATH = os.path.join(BASE_DIR, 'ml', 'house_price_model.pkl')
model = joblib.load(MODEL_PATH) if os.path.exists(MODEL_PATH) else None

# Seven well-known sub-locations for every location available in the estimator.
SUB_LOCATIONS = {'Nellore': ['Magunta Layout', 'Dargamitta', 'Balaji Nagar', 'Ramalingapuram', 'Vedayapalem', 'Pogathota', 'Stonehousepet'], 'Vijayawada': ['Benz Circle', 'Moghalrajpuram', 'Governorpet', 'Patamata', 'Labbipet', 'Poranki', 'Kanuru'], 'Hyderabad': ['Banjara Hills', 'Jubilee Hills', 'Gachibowli', 'HITEC City', 'Madhapur', 'Kondapur', 'Kukatpally'], 'Bangalore': ['Indiranagar', 'Koramangala', 'Whitefield', 'Jayanagar', 'HSR Layout', 'Malleshwaram', 'Electronic City'], 'Chennai': ['Anna Nagar', 'T. Nagar', 'Adyar', 'Velachery', 'OMR', 'Besant Nagar', 'Nungambakkam'], 'Mumbai': ['Bandra West', 'Andheri West', 'Powai', 'Colaba', 'Juhu', 'Lower Parel', 'Worli'], 'Tirupati': ['Tirumala', 'Alipiri', 'Renigunta Road', 'Tiruchanur', 'Korlagunta', 'Leela Mahal', 'Padmavathi Nagar'], 'Visakhapatnam': ['MVP Colony', 'Seethammadhara', 'Madhurawada', 'Gajuwaka', 'Dwaraka Nagar', 'Akkayyapalem', 'Rushikonda'], 'Guntur': ['Brodipet', 'Arundelpet', 'Lakshmipuram', 'Amaravathi Road', 'Pattabhipuram', 'Kothapet', 'Nallapadu'], 'Amaravati': ['Thullur', 'Mangalagiri', 'Tadepalli', 'Undavalli', 'Velagapudi', 'Rayapudi', 'Venkatapalem'], 'Kochi': ['Kakkanad', 'Edappally', 'Fort Kochi', 'Vyttila', 'Panampilly Nagar', 'Marine Drive', 'Kaloor'], 'Coimbatore': ['RS Puram', 'Saibaba Colony', 'Gandhipuram', 'Peelamedu', 'Race Course', 'Singanallur', 'Avinashi Road'], 'Mysore': ['Vijayanagar', 'Hebbal', 'Saraswathipuram', 'Jayalakshmipuram', 'Kuvempunagar', 'Gokulam', 'VV Mohalla'], 'Pune': ['Kothrud', 'Baner', 'Viman Nagar', 'Koregaon Park', 'Hinjewadi', 'Wakad', 'Aundh'], 'Delhi': ['Connaught Place', 'Dwarka', 'Rohini', 'Saket', 'Vasant Kunj', 'Greater Kailash', 'Hauz Khas']}


def user_required():
    return session.get('role') == 'user' and session.get('user_id')


def admin_required():
    return session.get('role') == 'admin' and session.get('admin_id')


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/user/register', methods=['GET', 'POST'])
def user_register():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm = request.form.get('confirm_password', password)
        if not name or not email or not password:
            flash('Please fill in all required fields.', 'danger')
            return render_template('auth/user_register.html')
        if password != confirm:
            flash('Passwords do not match.', 'danger')
            return render_template('auth/user_register.html')
        if User.query.filter_by(email=email).first():
            flash('Email is already registered. Please log in.', 'warning')
            return redirect(url_for('user_login'))
        user = User(name=name, email=email, password=generate_password_hash(password))
        db.session.add(user)
        db.session.commit()
        flash('Registration successful. You can now log in.', 'success')
        return redirect(url_for('user_login'))
    return render_template('auth/user_register.html')


@app.route('/user/login', methods=['GET', 'POST'])
def user_login():
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password, password):
            session.clear()
            session.update(user_id=user.id, user_name=user.name, role='user')
            db.session.add(LoginHistory(user_id=user.id, ip_address=request.remote_addr))
            db.session.commit()
            return redirect(url_for('user_dashboard'))
        flash('Invalid email or password.', 'danger')
    return render_template('auth/user_login.html')


@app.route('/user/dashboard')
def user_dashboard():
    if not user_required():
        return redirect(url_for('user_login'))
    user_id = session['user_id']
    predictions = Prediction.query.filter_by(user_id=user_id).order_by(Prediction.created_at.desc()).all()
    total = len(predictions)
    average = sum(p.predicted_price for p in predictions) / total if total else 0
    latest = predictions[0] if predictions else None
    return render_template('user/dashboard.html', user_name=session.get('user_name'), predictions=predictions, total_predictions=total, average_prediction=average, latest=latest)


@app.route('/user/predict', methods=['GET', 'POST'])
def user_predict():
    if not user_required():
        return redirect(url_for('user_login'))
    if request.method == 'POST':
        try:
            location = request.form.get('location', '').strip()
            sub_location = request.form.get('sub_location', '').strip()
            area = float(request.form.get('area', 0))
            bedrooms = int(request.form.get('bedrooms', 0))
            bathrooms = int(request.form.get('bathrooms', 0))
            parking = int(request.form.get('parking', 0))
            floor = int(request.form.get('floor', 0))

            if location not in SUB_LOCATIONS:
                raise ValueError('Please select a valid location.')
            if sub_location not in SUB_LOCATIONS[location]:
                raise ValueError('Please select a valid sub-location for the selected location.')
            if not location or area <= 0 or bedrooms <= 0 or bathrooms <= 0:
                raise ValueError('Enter valid property details.')
            if model is None:
                raise RuntimeError('ML model is missing. Run ml/train_model.py first.')

            features = pd.DataFrame([{
                'location': location,
                'sub_location': sub_location,
                'area': area,
                'bedrooms': bedrooms,
                'bathrooms': bathrooms,
                'parking': parking,
                'floor': floor
            }])
            predicted_price = float(model.predict(features)[0])

            prediction = Prediction(
                user_id=session['user_id'],
                location=location,
                sub_location=sub_location,
                area=area,
                bedrooms=bedrooms,
                bathrooms=bathrooms,
                parking=parking,
                floor=floor,
                predicted_price=predicted_price
            )
            db.session.add(prediction)
            db.session.commit()
            return render_template('user/prediction_result.html', prediction=prediction)
        except (ValueError, TypeError) as exc:
            flash(str(exc), 'danger')
        except Exception as exc:
            db.session.rollback()
            flash(f'Prediction failed: {exc}', 'danger')
    return render_template('user/prediction.html', sub_locations=SUB_LOCATIONS)


@app.route('/user/history')
def user_history():
    if not user_required():
        return redirect(url_for('user_login'))
    predictions = Prediction.query.filter_by(user_id=session['user_id']).order_by(Prediction.created_at.desc()).all()
    return render_template('user/history.html', predictions=predictions)


@app.route('/user/history/delete/<int:prediction_id>', methods=['POST'])
def delete_prediction(prediction_id):
    if not user_required():
        return redirect(url_for('user_login'))
    prediction = Prediction.query.filter_by(id=prediction_id, user_id=session['user_id']).first_or_404()
    db.session.delete(prediction)
    db.session.commit()
    flash('Prediction deleted.', 'success')
    return redirect(url_for('user_history'))


@app.route('/user/profile', methods=['GET', 'POST'])
def user_profile():
    if not user_required():
        return redirect(url_for('user_login'))
    user = User.query.get_or_404(session['user_id'])
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        existing = User.query.filter(User.email == email, User.id != user.id).first()
        if not name or not email:
            flash('Name and email are required.', 'danger')
        elif existing:
            flash('That email is already in use.', 'danger')
        else:
            user.name, user.email = name, email
            session['user_name'] = name
            db.session.commit()
            flash('Profile updated successfully.', 'success')
            return redirect(url_for('user_profile'))
    return render_template('user/profile.html', user=user)


@app.route('/user/login-details')
def user_login_details():
    if not user_required():
        return redirect(url_for('user_login'))
    history = LoginHistory.query.filter_by(user_id=session['user_id']).order_by(LoginHistory.login_time.desc()).all()
    return render_template('user/login_details.html', login_history=history)


@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        admin = Admin.query.filter_by(email=email).first()
        if admin and check_password_hash(admin.password, password):
            session.clear()
            session.update(admin_id=admin.id, admin_name=admin.name, role='admin')
            return redirect(url_for('admin_dashboard'))
        flash('Invalid admin email or password.', 'danger')
    return render_template('auth/admin_login.html')


@app.route('/admin/dashboard')
def admin_dashboard():
    if not admin_required():
        return redirect(url_for('admin_login'))

    total_users = User.query.count()
    total_predictions = Prediction.query.count()
    total_logins = LoginHistory.query.count()
    active_sessions = LoginHistory.query.filter(LoginHistory.logout_time.is_(None)).count()
    average_prediction = db.session.query(db.func.avg(Prediction.predicted_price)).scalar() or 0

    # Real activity from the database, newest first.
    recent_predictions = Prediction.query.order_by(Prediction.created_at.desc()).limit(5).all()
    recent_logins = LoginHistory.query.order_by(LoginHistory.login_time.desc()).limit(5).all()
    recent_users = User.query.order_by(User.created_at.desc()).limit(5).all()

    activities = []
    for u in recent_users:
        activities.append((u.created_at, 'user', 'New user registered', u.name, u.id))
    for p in recent_predictions:
        activities.append((p.created_at, 'prediction', 'New prediction generated', p.user.name if p.user else 'Unknown user', p.id))
    for l in recent_logins:
        activities.append((l.login_time, 'login', 'User login successful', l.user.name if l.user else 'Unknown user', l.user_id))
    activities.sort(key=lambda x: x[0] or '', reverse=True)

    return render_template(
        'admin/dashboard.html',
        total_users=total_users,
        total_predictions=total_predictions,
        total_logins=total_logins,
        active_sessions=active_sessions,
        average_prediction=average_prediction,
        activities=activities[:8]
    )


@app.route('/admin/users')
def admin_users():
    if not admin_required(): return redirect(url_for('admin_login'))
    return render_template('admin/users.html', users=User.query.order_by(User.created_at.desc()).all())


@app.route('/admin/users/<int:user_id>')
def admin_user_details(user_id):
    if not admin_required():
        return redirect(url_for('admin_login'))

    user = User.query.get_or_404(user_id)
    predictions = (
        Prediction.query
        .filter_by(user_id=user.id)
        .order_by(Prediction.created_at.desc())
        .all()
    )
    login_history = (
        LoginHistory.query
        .filter_by(user_id=user.id)
        .order_by(LoginHistory.login_time.desc())
        .all()
    )

    total_predictions = len(predictions)
    average_prediction = (
        sum((p.predicted_price or 0) for p in predictions) / total_predictions
        if total_predictions else 0
    )

    location_counts = {}
    for prediction in predictions:
        if prediction.location:
            location_counts[prediction.location] = location_counts.get(prediction.location, 0) + 1
    most_used_location = (
        max(location_counts, key=location_counts.get)
        if location_counts else 'No predictions yet'
    )

    last_login = login_history[0].login_time if login_history else None

    return render_template(
        'admin/user_details.html',
        user=user,
        predictions=predictions,
        login_history=login_history,
        total_predictions=total_predictions,
        average_prediction=average_prediction,
        most_used_location=most_used_location,
        last_login=last_login
    )


@app.route('/admin/users/delete/<int:user_id>', methods=['POST'])
def delete_user(user_id):
    if not admin_required(): return redirect(url_for('admin_login'))
    user = User.query.get_or_404(user_id)
    db.session.delete(user)
    db.session.commit()
    flash('User deleted.', 'success')
    return redirect(url_for('admin_users'))


@app.route('/admin/predictions')
def admin_predictions():
    if not admin_required(): return redirect(url_for('admin_login'))
    return render_template('admin/predictions.html', predictions=Prediction.query.order_by(Prediction.created_at.desc()).all())


@app.route('/admin/login-history')
def admin_login_history():
    if not admin_required(): return redirect(url_for('admin_login'))
    return render_template('admin/login_history.html', login_history=LoginHistory.query.order_by(LoginHistory.login_time.desc()).all())


@app.route('/admin/analytics')
def admin_analytics():
    if not admin_required():
        return redirect(url_for('admin_login'))

    total_users = User.query.count()
    total_predictions = Prediction.query.count()
    total_logins = LoginHistory.query.count()
    active_sessions = LoginHistory.query.filter(LoginHistory.logout_time.is_(None)).count()
    average_prediction = db.session.query(db.func.avg(Prediction.predicted_price)).scalar() or 0

    # Aggregate actual prediction records by date.
    rows = db.session.query(
        db.func.date(Prediction.created_at).label('day'),
        db.func.count(Prediction.id).label('count'),
        db.func.avg(Prediction.predicted_price).label('average_price')
    ).group_by(db.func.date(Prediction.created_at)).order_by(db.func.date(Prediction.created_at)).all()

    chart_labels = [r.day for r in rows]
    prediction_counts = [int(r.count) for r in rows]
    average_prices = [round(float(r.average_price or 0), 2) for r in rows]

    location_rows = db.session.query(
        Prediction.location, db.func.count(Prediction.id)
    ).group_by(Prediction.location).order_by(db.func.count(Prediction.id).desc()).all()
    location_labels = [r[0] or 'Unknown' for r in location_rows[:10]]
    location_counts = [int(r[1]) for r in location_rows[:10]]

    return render_template(
        'admin/analytics.html',
        total_users=total_users,
        total_predictions=total_predictions,
        total_logins=total_logins,
        active_sessions=active_sessions,
        average_prediction=average_prediction,
        chart_labels=chart_labels,
        prediction_counts=prediction_counts,
        average_prices=average_prices,
        location_labels=location_labels,
        location_counts=location_counts
    )


@app.route('/admin/profile', methods=['GET', 'POST'])
def admin_profile():
    if not admin_required(): return redirect(url_for('admin_login'))
    admin = Admin.query.get_or_404(session['admin_id'])
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        existing = Admin.query.filter(Admin.email == email, Admin.id != admin.id).first()
        if not name or not email: flash('Name and email are required.', 'danger')
        elif existing: flash('That email is already in use.', 'danger')
        else:
            admin.name, admin.email = name, email
            session['admin_name'] = name
            db.session.commit()
            flash('Admin profile updated.', 'success')
            return redirect(url_for('admin_profile'))
    return render_template('admin/profile.html', admin=admin)


@app.route('/logout')
def logout():
    if session.get('role') == 'user':
        record = LoginHistory.query.filter_by(user_id=session.get('user_id')).order_by(LoginHistory.login_time.desc()).first()
        if record and record.logout_time is None:
            record.logout_time = get_ist_now()
            db.session.commit()
    session.clear()
    return redirect(url_for('home'))


with app.app_context():
    os.makedirs(os.path.join(BASE_DIR, 'database'), exist_ok=True)
    db.create_all()

    # Add the new column when upgrading an existing SQLite database.
    inspector = db.inspect(db.engine)
    prediction_columns = {column['name'] for column in inspector.get_columns('prediction')}
    if 'sub_location' not in prediction_columns:
        with db.engine.begin() as connection:
            connection.exec_driver_sql(
                'ALTER TABLE prediction ADD COLUMN sub_location VARCHAR(100)'
            )

    # Give older prediction records a valid sub-location so old history remains complete.
    old_predictions = Prediction.query.filter(
        Prediction.sub_location.is_(None)
    ).all()
    for old_prediction in old_predictions:
        choices = SUB_LOCATIONS.get(old_prediction.location, [])
        if choices:
            old_prediction.sub_location = choices[(old_prediction.id - 1) % len(choices)]
    if old_predictions:
        db.session.commit()


if __name__ == '__main__':
    app.run(debug=True)
